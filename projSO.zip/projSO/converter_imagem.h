#ifndef CONVERTER_IMAGEM_H
#define CONVERTER_IMAGEM_H

void converter_imagem(const char *input_path);

#endif
